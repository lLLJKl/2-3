import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import { BrowserRouter, Routes, Route } from "react-router";
import UserEdit from "@/pages/UserEdit.jsx";
import UserView from "@/pages/UserView.jsx";
import BoardView from "@/pages/BoardView.jsx";


const App = () => {
  const paths = [

    {path: "/boardview", element: <BoardView />},
    {path: "/userview", element: <UserView />},
    {path: "/useredit", element: <UserEdit />},
   
  ]
  return (
    <>
      <BrowserRouter>
        <Routes>
          { paths?.map((v, i) => <Route key={i} path={v.path} element={v.element} />) }
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App